"use strict";
var Config;
(function (Config) {
    class Game {
    }
    Game.SCREEN_WIDTH = 640;
    Game.SCREEN_HEIGHT = 480;
    Game.CENTER_X = 320;
    Game.CENTER_Y = 240;
    Game.FPS = 60; // 60 Frames per second
    Config.Game = Game;
})(Config || (Config = {}));
//# sourceMappingURL=game.js.map